%% Run this file for the PD Tuning Gui
clear all
close all

pd_control_gui